function EffectEditorMessagesHandler(message)
	if message:is("EffectEditor", "Exit") then
		Screen:popLayer()
	end
end
