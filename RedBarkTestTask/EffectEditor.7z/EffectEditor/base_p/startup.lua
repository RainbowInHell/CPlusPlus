--LoadResource("Game/Resources.xml")
--GUI:LoadLayers("Game/Layers.xml")

Include("EffectEditor/Scripts.lua")
LoadResource("EffectEditor/Resources.xml")
GUI:LoadLayers("EffectEditor/Layers.xml")

--UploadResourceGroup("Game")
--Screen:pushLayer(GUI:getLayer("GameLayer"))

Screen:pushLayer(GUI:getLayer("EffectEditorLayer"))
